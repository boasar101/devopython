from django.contrib import admin
from .models import *
admin.site.register(feauters)
admin.site.register(fields)
admin.site.register(Востребованно)
admin.site.register(Географ)
admin.site.register(Навык)
admin.site.register(Послед)

# Register your models here.
